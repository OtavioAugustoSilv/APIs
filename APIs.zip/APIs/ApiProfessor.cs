﻿using Microsoft.AspNetCore.Mvc;

namespace FormsBanco.Controllers
{
    public class ApiProfessor : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
