﻿using Microsoft.AspNetCore.Mvc;
using StudentHub.Models;

namespace FormsBanco.Controllers
{
    public class MateriaApi : Controller
    {
        [Route("api/[controller]")]
        [ApiController]
        public class MateriaController : ControllerBase
        {
            [HttpGet]
            public ActionResult<List<Materia>> Busca()
            {
                Materia materia = new Materia("", "");
                return materia.BuscarDados();
            }

            [HttpPost]
            public ActionResult<string> Inserir([FromBody] List<Materia> materias, int serie)
            {
                Materia materia = new Materia("", "");
                materia.EnviarDados(materias, serie);
                return "Dados enviados com sucesso!";
            }
        }
    }
}
