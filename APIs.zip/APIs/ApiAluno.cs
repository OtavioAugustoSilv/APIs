﻿using Microsoft.AspNetCore.Mvc;
using Projeto.Models;

namespace FormsBanco.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AlunoController : ControllerBase
    {
        [HttpGet]
        public ActionResult<List<Aluno>> Busca()
        {
            return Aluno.BuscarTodos();
        }

        [HttpPost]
        public ActionResult<string> Inserir([FromBody] Aluno aluno)
        {
            return aluno.Inserir();
        }
    }
}
