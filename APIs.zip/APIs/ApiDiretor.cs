﻿using Microsoft.AspNetCore.Mvc;
using Projeto.Models;

namespace FormsBanco.Controllers
{
    public class ApiDiretor : Controller
    {
        [Route("api/[controller]")]
        [ApiController]
        public class DiretorController : ControllerBase
        {
            [HttpGet]
            public ActionResult<List<Diretor>> Get()
            {
                return Diretor.BuscarTodos();
            }

            [HttpPost]
            public ActionResult<string> Post([FromBody] Diretor diretor)
            {
                return diretor.Inserir();
            }
        }
    }
}
