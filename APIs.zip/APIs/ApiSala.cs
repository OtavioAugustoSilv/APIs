﻿using FormsBanco.Models;
using Microsoft.AspNetCore.Mvc;

namespace FormsBanco.Controllers
{
    public class ApiSala : Controller
    {
        [Route("api/[controller]")]
        [ApiController]
        public class SalaController : ControllerBase
        {
            [HttpGet]
            public ActionResult<List<Sala>> Get()
            {
                return Sala.buscarSalas();
            }

            [HttpPost]
            public ActionResult<string> Post([FromBody] Sala sala)
            {
                return sala.Inserir();
            }
        }
    }
}
